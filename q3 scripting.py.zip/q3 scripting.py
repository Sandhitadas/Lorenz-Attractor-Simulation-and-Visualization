import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.integrate import solve_ivp

# Lorenz equations
def lorenz(t, xyz, sigma, rho, beta):
    x, y, z = xyz
    dxdt = sigma * (y - x)
    dydt = x * (rho - z) - y
    dzdt = x * y - beta * z
    return [dxdt, dydt, dzdt]

# Parameters
sigma = 10
rho = 28
beta = 8/3

# Initial conditions for particle A
initial_conditions_A = [1.0, 1.0, 1.0]

# Initial conditions for particle B (slightly different)
initial_conditions_B = [1.0 + 0.001, 1.0 + 0.001, 1.0 + 0.001]

# Time span
t_span = (0, 50)
t_eval = np.linspace(*t_span, 10000)

# Solve differential equations for both particles
sol_A = solve_ivp(lorenz, t_span, initial_conditions_A, args=(sigma, rho, beta), t_eval=t_eval)
sol_B = solve_ivp(lorenz, t_span, initial_conditions_B, args=(sigma, rho, beta), t_eval=t_eval)

# Plotting
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Plot trajectory of particle A
ax.plot(sol_A.y[0], sol_A.y[1], sol_A.y[2], 'b-', label='Particle A')

# Plot trajectory of particle B
ax.plot(sol_B.y[0], sol_B.y[1], sol_B.y[2], 'r-', label='Particle B')

# Plot the attractor itself
x_attractor = np.linspace(-20, 20, 400)
y_attractor = np.linspace(-30, 30, 400)
z_attractor = np.linspace(0, 50, 400)
X, Y, Z = np.meshgrid(x_attractor, y_attractor, z_attractor)
ax.plot(X, Y, Z, alpha=0.2, color='gray')

# Customize plot
ax.set_title('Lorenz Attractor')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.legend()

plt.show()
